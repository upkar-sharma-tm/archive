
// adding new custom advanceDescription //
class advanceDescriptionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('advanceDescription'); 
        } 
} customElements.define('tmna-advancedescription', advanceDescriptionClass); 
        
    
// adding new custom advanceDescriptionTitle //
class advanceDescriptionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('advanceDescriptionTitle'); 
        } 
} customElements.define('tmna-advancedescriptiontitle', advanceDescriptionTitleClass); 
        
    
// adding new custom advanceFunction //
class advanceFunctionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('advanceFunction'); 
        } 
} customElements.define('tmna-advancefunction', advanceFunctionClass); 
        
    
// adding new custom advanceFunctionTitle //
class advanceFunctionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('advanceFunctionTitle'); 
        } 
} customElements.define('tmna-advancefunctiontitle', advanceFunctionTitleClass); 
        
    
// adding new custom advanceOperation //
class advanceOperationClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('advanceOperation'); 
        } 
} customElements.define('tmna-advanceoperation', advanceOperationClass); 
        
    
// adding new custom advanceOperationTitle //
class advanceOperationTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('advanceOperationTitle'); 
        } 
} customElements.define('tmna-advanceoperationtitle', advanceOperationTitleClass); 
        
    
// adding new custom alert //
class alertClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('alert'); 
        } 
} customElements.define('tmna-alert', alertClass); 
        
    
// adding new custom alertTitle //
class alertTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('alertTitle'); 
        } 
} customElements.define('tmna-alerttitle', alertTitleClass); 
        
    
// adding new custom alphaIndex //
class alphaIndexClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('alphaIndex'); 
        } 
} customElements.define('tmna-alphaindex', alphaIndexClass); 
        
    
// adding new custom alphaIndexList1 //
class alphaIndexList1Class extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('alphaIndexList1'); 
        } 
} customElements.define('tmna-alphaindexlist1', alphaIndexList1Class); 
        
    
// adding new custom alphaIndexList2 //
class alphaIndexList2Class extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('alphaIndexList2'); 
        } 
} customElements.define('tmna-alphaindexlist2', alphaIndexList2Class); 
        
    
// adding new custom alphaIndexListItem //
class alphaIndexListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('alphaIndexListItem'); 
        } 
} customElements.define('tmna-alphaindexlistitem', alphaIndexListItemClass); 
        
    
// adding new custom attention //
class attentionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attention'); 
        } 
} customElements.define('tmna-attention', attentionClass); 
        
    
// adding new custom attentionCallout //
class attentionCalloutClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionCallout'); 
        } 
} customElements.define('tmna-attentioncallout', attentionCalloutClass); 
        
    
// adding new custom attentionFigure //
class attentionFigureClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionFigure'); 
        } 
} customElements.define('tmna-attentionfigure', attentionFigureClass); 
        
    
// adding new custom attentionList //
class attentionListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionList'); 
        } 
} customElements.define('tmna-attentionlist', attentionListClass); 
        
    
// adding new custom attentionListItem //
class attentionListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionListItem'); 
        } 
} customElements.define('tmna-attentionlistitem', attentionListItemClass); 
        
    
// adding new custom attentionPara //
class attentionParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionPara'); 
        } 
} customElements.define('tmna-attentionpara', attentionParaClass); 
        
    
// adding new custom attentionParaTitle //
class attentionParaTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionParaTitle'); 
        } 
} customElements.define('tmna-attentionparatitle', attentionParaTitleClass); 
        
    
// adding new custom attentionStep //
class attentionStepClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionStep'); 
        } 
} customElements.define('tmna-attentionstep', attentionStepClass); 
        
    
// adding new custom attentionStepItem //
class attentionStepItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionStepItem'); 
        } 
} customElements.define('tmna-attentionstepitem', attentionStepItemClass); 
        
    
// adding new custom attentionSubList //
class attentionSubListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionSubList'); 
        } 
} customElements.define('tmna-attentionsublist', attentionSubListClass); 
        
    
// adding new custom attentionSubListItem //
class attentionSubListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionSubListItem'); 
        } 
} customElements.define('tmna-attentionsublistitem', attentionSubListItemClass); 
        
    
// adding new custom attentionTitle //
class attentionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('attentionTitle'); 
        } 
} customElements.define('tmna-attentiontitle', attentionTitleClass); 
        
    
// adding new custom autoControls //
class autoControlsClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('autoControls'); 
        } 
} customElements.define('tmna-autocontrols', autoControlsClass); 
        
    
// adding new custom autoControlsTitle //
class autoControlsTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('autoControlsTitle'); 
        } 
} customElements.define('tmna-autocontrolstitle', autoControlsTitleClass); 
        
    
// adding new custom basicDescription //
class basicDescriptionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('basicDescription'); 
        } 
} customElements.define('tmna-basicdescription', basicDescriptionClass); 
        
    
// adding new custom basicDescriptionTitle //
class basicDescriptionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('basicDescriptionTitle'); 
        } 
} customElements.define('tmna-basicdescriptiontitle', basicDescriptionTitleClass); 
        
    
// adding new custom basicFunction //
class basicFunctionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('basicFunction'); 
        } 
} customElements.define('tmna-basicfunction', basicFunctionClass); 
        
    
// adding new custom basicFunctionTitle //
class basicFunctionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('basicFunctionTitle'); 
        } 
} customElements.define('tmna-basicfunctiontitle', basicFunctionTitleClass); 
        
    
// adding new custom basicOperation //
class basicOperationClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('basicOperation'); 
        } 
} customElements.define('tmna-basicoperation', basicOperationClass); 
        
    
// adding new custom basicOperationTitle //
class basicOperationTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('basicOperationTitle'); 
        } 
} customElements.define('tmna-basicoperationtitle', basicOperationTitleClass); 
        
    
// adding new custom bodyParaGrp //
class bodyParaGrpClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('bodyParaGrp'); 
        } 
} customElements.define('tmna-bodyparagrp', bodyParaGrpClass); 
        
    
// adding new custom bodyParaGrpTitle //
class bodyParaGrpTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('bodyParaGrpTitle'); 
        } 
} customElements.define('tmna-bodyparagrptitle', bodyParaGrpTitleClass); 
        
    
// adding new custom bodyTitle //
class bodyTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('bodyTitle'); 
        } 
} customElements.define('tmna-bodytitle', bodyTitleClass); 
        
    
// adding new custom callout //
class calloutClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('callout'); 
        } 
} customElements.define('tmna-callout', calloutClass); 
        
    
// adding new custom calloutList //
class calloutListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('calloutList'); 
        } 
} customElements.define('tmna-calloutlist', calloutListClass); 
        
    
// adding new custom calloutOrderList //
class calloutOrderListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('calloutOrderList'); 
        } 
} customElements.define('tmna-calloutorderlist', calloutOrderListClass); 
        
    
// adding new custom calloutOrderListItem //
class calloutOrderListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('calloutOrderListItem'); 
        } 
} customElements.define('tmna-calloutorderlistitem', calloutOrderListItemClass); 
        
    
// adding new custom calloutPara //
class calloutParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('calloutPara'); 
        } 
} customElements.define('tmna-calloutpara', calloutParaClass); 
        
    
// adding new custom calloutParaSub //
class calloutParaSubClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('calloutParaSub'); 
        } 
} customElements.define('tmna-calloutparasub', calloutParaSubClass); 
        
    
// adding new custom callouts //
class calloutsClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('callouts'); 
        } 
} customElements.define('tmna-callouts', calloutsClass); 
        
    
// adding new custom calloutsTitle //
class calloutsTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('calloutsTitle'); 
        } 
} customElements.define('tmna-calloutstitle', calloutsTitleClass); 
        
    
// adding new custom calloutSymbol //
class calloutSymbolClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('calloutSymbol'); 
        } 
} customElements.define('tmna-calloutsymbol', calloutSymbolClass); 
        
    
// adding new custom calloutTitle //
class calloutTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('calloutTitle'); 
        } 
} customElements.define('tmna-callouttitle', calloutTitleClass); 
        
    
// adding new custom diagnosisBody //
class diagnosisBodyClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisBody'); 
        } 
} customElements.define('tmna-diagnosisbody', diagnosisBodyClass); 
        
    
// adding new custom diagnosisCallout //
class diagnosisCalloutClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisCallout'); 
        } 
} customElements.define('tmna-diagnosiscallout', diagnosisCalloutClass); 
        
    
// adding new custom diagnosisFigure //
class diagnosisFigureClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisFigure'); 
        } 
} customElements.define('tmna-diagnosisfigure', diagnosisFigureClass); 
        
    
// adding new custom diagnosisList //
class diagnosisListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisList'); 
        } 
} customElements.define('tmna-diagnosislist', diagnosisListClass); 
        
    
// adding new custom diagnosisListItem //
class diagnosisListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisListItem'); 
        } 
} customElements.define('tmna-diagnosislistitem', diagnosisListItemClass); 
        
    
// adding new custom diagnosisPara //
class diagnosisParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisPara'); 
        } 
} customElements.define('tmna-diagnosispara', diagnosisParaClass); 
        
    
// adding new custom diagnosisParaSub //
class diagnosisParaSubClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisParaSub'); 
        } 
} customElements.define('tmna-diagnosisparasub', diagnosisParaSubClass); 
        
    
// adding new custom diagnosisResult //
class diagnosisResultClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisResult'); 
        } 
} customElements.define('tmna-diagnosisresult', diagnosisResultClass); 
        
    
// adding new custom diagnosisResultPara //
class diagnosisResultParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisResultPara'); 
        } 
} customElements.define('tmna-diagnosisresultpara', diagnosisResultParaClass); 
        
    
// adding new custom diagnosisSection //
class diagnosisSectionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisSection'); 
        } 
} customElements.define('tmna-diagnosissection', diagnosisSectionClass); 
        
    
// adding new custom diagnosisSubList //
class diagnosisSubListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisSubList'); 
        } 
} customElements.define('tmna-diagnosissublist', diagnosisSubListClass); 
        
    
// adding new custom diagnosisSubListItem //
class diagnosisSubListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('diagnosisSubListItem'); 
        } 
} customElements.define('tmna-diagnosissublistitem', diagnosisSubListItemClass); 
        
    
// adding new custom explanation //
class explanationClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('explanation'); 
        } 
} customElements.define('tmna-explanation', explanationClass); 
        
    
// adding new custom explanationTitle //
class explanationTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('explanationTitle'); 
        } 
} customElements.define('tmna-explanationtitle', explanationTitleClass); 
        
    
// adding new custom figure //
class figureClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('figure'); 
        } 
} customElements.define('tmna-figure', figureClass); 
        
    
// adding new custom footnote //
class footnoteClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('footnote'); 
        } 
} customElements.define('tmna-footnote', footnoteClass); 
        
    
// adding new custom indexterm //
class indextermClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('indexterm'); 
        } 
} customElements.define('tmna-indexterm', indextermClass); 
        
    
// adding new custom introPara //
class introParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('introPara'); 
        } 
} customElements.define('tmna-intropara', introParaClass); 
        
    
// adding new custom introParaFigure //
class introParaFigureClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('introParaFigure'); 
        } 
} customElements.define('tmna-introparafigure', introParaFigureClass); 
        
    
// adding new custom introParaList //
class introParaListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('introParaList'); 
        } 
} customElements.define('tmna-introparalist', introParaListClass); 
        
    
// adding new custom introParaListItem //
class introParaListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('introParaListItem'); 
        } 
} customElements.define('tmna-introparalistitem', introParaListItemClass); 
        
    
// adding new custom list //
class listClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('list'); 
        } 
} customElements.define('tmna-list', listClass); 
        
    
// adding new custom listItem //
class listItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('listItem'); 
        } 
} customElements.define('tmna-listitem', listItemClass); 
        
    
// adding new custom listItemPara //
class listItemParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('listItemPara'); 
        } 
} customElements.define('tmna-listitempara', listItemParaClass); 
        
    
// adding new custom listItemParaSub //
class listItemParaSubClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('listItemParaSub'); 
        } 
} customElements.define('tmna-listitemparasub', listItemParaSubClass); 
        
    
// adding new custom note //
class noteClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('note'); 
        } 
} customElements.define('tmna-note', noteClass); 
        
    
// adding new custom notePara //
class noteParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('notePara'); 
        } 
} customElements.define('tmna-notepara', noteParaClass); 
        
    
// adding new custom noteParaTitle //
class noteParaTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('noteParaTitle'); 
        } 
} customElements.define('tmna-noteparatitle', noteParaTitleClass); 
        
    
// adding new custom noteTitle //
class noteTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('noteTitle'); 
        } 
} customElements.define('tmna-notetitle', noteTitleClass); 
        
    
// adding new custom para //
class paraClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('para'); 
        } 
} customElements.define('tmna-para', paraClass); 
        
    
// adding new custom paraCallout //
class paraCalloutClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('paraCallout'); 
        } 
} customElements.define('tmna-paracallout', paraCalloutClass); 
        
    
// adding new custom paraSelect //
class paraSelectClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('paraSelect'); 
        } 
} customElements.define('tmna-paraselect', paraSelectClass); 
        
    
// adding new custom paraSelectDiv //
class paraSelectDivClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('paraSelectDiv'); 
        } 
} customElements.define('tmna-paraselectdiv', paraSelectDivClass); 
        
    
// adding new custom paraSelectDivTitle //
class paraSelectDivTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('paraSelectDivTitle'); 
        } 
} customElements.define('tmna-paraselectdivtitle', paraSelectDivTitleClass); 
        
    
// adding new custom paraSub //
class paraSubClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('paraSub'); 
        } 
} customElements.define('tmna-parasub', paraSubClass); 
        
    
// adding new custom reference //
class referenceClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('reference'); 
        } 
} customElements.define('tmna-reference', referenceClass); 
        
    
// adding new custom refList //
class refListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('refList'); 
        } 
} customElements.define('tmna-reflist', refListClass); 
        
    
// adding new custom refPara //
class refParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('refPara'); 
        } 
} customElements.define('tmna-refpara', refParaClass); 
        
    
// adding new custom stepList //
class stepListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('stepList'); 
        } 
} customElements.define('tmna-steplist', stepListClass); 
        
    
// adding new custom stepListItem //
class stepListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('stepListItem'); 
        } 
} customElements.define('tmna-steplistitem', stepListItemClass); 
        
    
// adding new custom stepPara //
class stepParaClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('stepPara'); 
        } 
} customElements.define('tmna-steppara', stepParaClass); 
        
    
// adding new custom stepParaSub //
class stepParaSubClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('stepParaSub'); 
        } 
} customElements.define('tmna-stepparasub', stepParaSubClass); 
        
    
// adding new custom subList //
class subListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subList'); 
        } 
} customElements.define('tmna-sublist', subListClass); 
        
    
// adding new custom subListItem //
class subListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subListItem'); 
        } 
} customElements.define('tmna-sublistitem', subListItemClass); 
        
    
// adding new custom subSecOverview //
class subSecOverviewClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSecOverview'); 
        } 
} customElements.define('tmna-subsecoverview', subSecOverviewClass); 
        
    
// adding new custom subSecTopic //
class subSecTopicClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSecTopic'); 
        } 
} customElements.define('tmna-subsectopic', subSecTopicClass); 
        
    
// adding new custom subSecTopicTitle //
class subSecTopicTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSecTopicTitle'); 
        } 
} customElements.define('tmna-subsectopictitle', subSecTopicTitleClass); 
        
    
// adding new custom subSubTopic //
class subSubTopicClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSubTopic'); 
        } 
} customElements.define('tmna-subsubtopic', subSubTopicClass); 
        
    
// adding new custom subSubTopicAdvFunction //
class subSubTopicAdvFunctionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSubTopicAdvFunction'); 
        } 
} customElements.define('tmna-subsubtopicadvfunction', subSubTopicAdvFunctionClass); 
        
    
// adding new custom subSubTopicAdvFunctionTitle //
class subSubTopicAdvFunctionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSubTopicAdvFunctionTitle'); 
        } 
} customElements.define('tmna-subsubtopicadvfunctiontitle', subSubTopicAdvFunctionTitleClass); 
        
    
// adding new custom subSubTopicBasicFunction //
class subSubTopicBasicFunctionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSubTopicBasicFunction'); 
        } 
} customElements.define('tmna-subsubtopicbasicfunction', subSubTopicBasicFunctionClass); 
        
    
// adding new custom subSubTopicBasicFunctionTitle //
class subSubTopicBasicFunctionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSubTopicBasicFunctionTitle'); 
        } 
} customElements.define('tmna-subsubtopicbasicfunctiontitle', subSubTopicBasicFunctionTitleClass); 
        
    
// adding new custom subSubTopicTitle //
class subSubTopicTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subSubTopicTitle'); 
        } 
} customElements.define('tmna-subsubtopictitle', subSubTopicTitleClass); 
        
    
// adding new custom subTopic //
class subTopicClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subTopic'); 
        } 
} customElements.define('tmna-subtopic', subTopicClass); 
        
    
// adding new custom subTopicAdvFunction //
class subTopicAdvFunctionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subTopicAdvFunction'); 
        } 
} customElements.define('tmna-subtopicadvfunction', subTopicAdvFunctionClass); 
        
    
// adding new custom subTopicAdvFunctionTitle //
class subTopicAdvFunctionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subTopicAdvFunctionTitle'); 
        } 
} customElements.define('tmna-subtopicadvfunctiontitle', subTopicAdvFunctionTitleClass); 
        
    
// adding new custom subTopicBasicFunction //
class subTopicBasicFunctionClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subTopicBasicFunction'); 
        } 
} customElements.define('tmna-subtopicbasicfunction', subTopicBasicFunctionClass); 
        
    
// adding new custom subTopicBasicFunctionTitle //
class subTopicBasicFunctionTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subTopicBasicFunctionTitle'); 
        } 
} customElements.define('tmna-subtopicbasicfunctiontitle', subTopicBasicFunctionTitleClass); 
        
    
// adding new custom subTopicBody //
class subTopicBodyClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subTopicBody'); 
        } 
} customElements.define('tmna-subtopicbody', subTopicBodyClass); 
        
    
// adding new custom subTopicBodyTitle //
class subTopicBodyTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subTopicBodyTitle'); 
        } 
} customElements.define('tmna-subtopicbodytitle', subTopicBodyTitleClass); 
        
    
// adding new custom subTopicTitle //
class subTopicTitleClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('subTopicTitle'); 
        } 
} customElements.define('tmna-subtopictitle', subTopicTitleClass); 
        
    
// adding new custom symbol //
class symbolClass extends HTMLElement { 
            constructor() { 
            super(); 
			var s = this.getAttribute('src');
			var h = this.getAttribute('height') + 'px';
			var w = this.getAttribute('width') + 'px';
            this.classList.add('symbol');
			this.style.height = h;
			this.style.width =  w;
			this.style.backgroundImage = 'url(' + s + ')';
			this.style.backgroundSize = 'contain';
      } 
} customElements.define('tmna-symbol', symbolClass);       
    
// adding new custom tableFigure //
class tableFigureClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('tableFigure'); 
        } 
} customElements.define('tmna-tablefigure', tableFigureClass); 
        
    
// adding new custom tableList //
class tableListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('tableList'); 
        } 
} customElements.define('tmna-tablelist', tableListClass); 
        
    
// adding new custom tableListItem //
class tableListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('tableListItem'); 
        } 
} customElements.define('tmna-tablelistitem', tableListItemClass); 
        
    
// adding new custom tableSubList //
class tableSubListClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('tableSubList'); 
        } 
} customElements.define('tmna-tablesublist', tableSubListClass); 
        
    
// adding new custom tableSubListItem //
class tableSubListItemClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('tableSubListItem'); 
        } 
} customElements.define('tmna-tablesublistitem', tableSubListItemClass); 
        
    
// adding new custom topicBody //
class topicBodyClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('topicBody'); 
        } 
} customElements.define('tmna-topicbody', topicBodyClass); 
        
    
// adding new custom uicontrol //
class uicontrolClass extends HTMLElement { 
        constructor() { 
        super(); 
        this.classList.add('uicontrol'); 
        } 
} customElements.define('tmna-uicontrol', uicontrolClass); 
        
    