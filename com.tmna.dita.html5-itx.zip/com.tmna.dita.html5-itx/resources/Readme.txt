﻿Objective: 
	To provide basic insight of the directory, sub-directories structure and html files.
Driver file: 
	index.html file inside the topics directory to provide toc with links
List of directories:
	•	common: to include common graphics
	•	image: publication specific images
	•	topics: index.html, base CSS files along with html files for each topic
Known issues:
	•	broken links in chapter files
	•	images sometimes appear rotated 90 degrees
	•	images are cropped and this needs to be resolved
	•	Most images are poor quality	
	•	VIN metadata is included now but will be removed.

***************************************   Updated:5/11/2021   *************************************************
Known issues:
	Items fixed
	•	images sometimes appear rotated 90 degrees
	•	images are cropped and this needs to be resolved
	•	Most images are poor quality	
	•	VIN metadata is included now but will be removed.
	

***************************************   Updated:6/11/2021   *************************************************
	Items fixed
	•	Organized directory and file structure per collected feedback
	•	Graphics and other resource files are systematically organized 
	•	HTML files are now XML compliant. i.e. tags like meta, img, br, etc now have matching end tags
	•	HTML source code is set to render as pretty print which is more human readable
	•	Meta keyword limitation is addressed by propagating indexterm across the document along with titles
	•	Zipped file with naming convention


*************************************** ****   Updated:7/14/2021   ******************** *************************************** 
Additional attributes @id and @resource added to the index page
	• @id attribute will hold the id of the linked html file
	• @resource attribute will define the resource type 

Implementation of semantic tags

	•Following semantic tags added to the HTML output -
		1.	tmna-advanceFunction
		2.	tmna-advanceFunctionTitle
		3.	tmna-basicFunction
		4.	tmna-basicFunctionTitle
		5.	tmna-bodyParaGrp
		6.	tmna-bodyParaGrpTitle
		7.	tmna-subSecOverview
		8.	tmna-subSecTopic
		9.	tmna-subSecTopicTitle
		10.	tmna-topicBody
		11.	tmna-topicTitle
		
	•Following new classes are added to HTML output and added to CSS file 	
		1.	.advanceFunction
		2.	.advanceFunctionTitle
		3.	.basicFunction
		4.	.basicFunctionTitle
		5.	.bodyParaGrp
		6.	.bodyParaGrpTitle
		7.	.subSecOverview
		8.	.subSecTopic
		9.	.subSecTopicTitle
		10.	.topicBody
		11.	.topicTitle
		
	• New JavaScript register-semantic-tags.js file is added to the output to register new tags.
	
	
*************************************** ****   Updated:8/06/2021   ******************** *************************************** 

Implementation of semantic tags

	•Following semantic tags added to the HTML output -
		1.	tmna-advanceDescription
		2.	tmna-advanceDescriptionTitle
		3.	tmna-advanceOperation
		4.	tmna-advanceOperationTitle
		5.	tmna-alert
		6.	tmna-alertTitle
		7.	tmna-alphaIndex
		8.	tmna-attention
		9.	tmna-attentionFigure
		10.	tmna-attentionPara
		11.	tmna-attentionParaTitle
		12.	tmna-attentionTitle
		13.	tmna-autoControls
		14.	tmna-autoControlsTitle
		15.	tmna-basicDescription
		16.	tmna-basicDescriptionTitle
		17.	tmna-basicOperation
		18.	tmna-basicOperationTitle
		19.	tmna-diagnosisBody
		20.	tmna-diagnosisFigure
		21.	tmna-diagnosisResult
		22.	tmna-diagnosisSection
		23.	tmna-explanation
		24.	tmna-explanationTitle
		25.	tmna-figure
		26.	tmna-indexterm
		27.	tmna-introParaFigure
		28.	tmna-note
		29.	tmna-notePara
		30.	tmna-noteParaTitle
		31.	tmna-noteTitle
		32.	tmna-paraSelectDiv
		33.	tmna-paraSelectDivTitle
		34.	tmna-paraSelectDivTitle
		35.	tmna-subSubTopic
		36.	tmna-subSubTopicAdvFunction
		37.	tmna-subSubTopicAdvFunctionTitle
		38.	tmna-subSubTopicBasicFunction
		39.	tmna-subSubTopicBasicFunctionTitle
		40.	tmna-subSubTopicTitle
		41.	tmna-subTopic
		42.	tmna-subTopicAdvFunction
		43.	tmna-subTopicAdvFunctionTitle
		44.	tmna-subTopicBasicFunction
		45.	tmna-subTopicBasicFunctionTitle
		46.	tmna-subTopicBody
		47.	tmna-subTopicBodyTitle
		48.	tmna-subTopicTitle
		49.	tmna-symbol
		50.	tmna-tableFigure

	•Following new classes are added to HTML output and added to CSS file
	
		1.	.advanceDescription
		2.	.advanceDescriptionTitle
		3.	.advanceOperation
		4.	.advanceOperationTitle
		5.	.alert
		6.	.alertTitle
		7.	.alphaIndex
		8.	.attention
		9.	.attentionFigure
		10.	.attentionPara
		11.	.attentionParaTitle
		12.	.attentionTitle
		13.	.autoControls
		14.	.autoControlsTitle
		15.	.basicDescription
		16.	.basicDescriptionTitle
		17.	.basicOperation
		18.	.basicOperationTitle
		19.	.diagnosisBody
		20.	.diagnosisFigure
		21.	.diagnosisResult
		22.	.diagnosisSection
		23.	.explanation
		24.	.explanationTitle
		25.	.figure
		26.	.indexterm
		27.	.introParaFigure
		28.	.note
		29.	.notePara
		30.	.noteParaTitle
		31.	.noteTitle
		32.	.paraSelectDiv
		33.	.paraSelectDivTitle
		34.	.paraSelectDivTitle
		35.	.subSubTopic
		36.	.subSubTopicAdvFunction
		37.	.subSubTopicAdvFunctionTitle
		38.	.subSubTopicBasicFunction
		39.	.subSubTopicBasicFunctionTitle
		40.	.subSubTopicTitle
		41.	.subTopic
		42.	.subTopicAdvFunction
		43.	.subTopicAdvFunctionTitle
		44.	.subTopicBasicFunction
		45.	.subTopicBasicFunctionTitle
		46.	.subTopicBody
		47.	.subTopicBodyTitle
		48.	.subTopicTitle
		49.	.symbol
		50.	.tableFigure

*************************************** ****   Updated:8/30/2021   ******************** *************************************** 

Complete list of Semantic Tags

		1) tmna-advanceDescription 
		2) tmna-advanceDescriptionTitle 
		3) tmna-advanceFunction 
		4) tmna-advanceFunctionTitle 
		5) tmna-advanceOperation 
		6) tmna-advanceOperationTitle 
		7) tmna-alert 
		8) tmna-alertTitle 
		9) tmna-alphaIndex 
		10) tmna-alphaIndexList1 
		11) tmna-alphaIndexList2 
		12) tmna-alphaIndexListItem 
		13) tmna-attention 
		14) tmna-attentionCallout 
		15) tmna-attentionFigure 
		16) tmna-attentionList 
		17) tmna-attentionListItem 
		18) tmna-attentionPara 
		19) tmna-attentionParaTitle 
		20) tmna-attentionStep 
		21) tmna-attentionStepItem 
		22) tmna-attentionSubList 
		23) tmna-attentionSubListItem 
		24) tmna-attentionTitle 
		25) tmna-autoControls 
		26) tmna-autoControlsTitle 
		27) tmna-basicDescription 
		28) tmna-basicDescriptionTitle 
		29) tmna-basicFunction 
		30) tmna-basicFunctionTitle 
		31) tmna-basicOperation 
		32) tmna-basicOperationTitle 
		33) tmna-bodyParaGrp 
		34) tmna-bodyParaGrpTitle 
		35) tmna-bodyTitle 
		36) tmna-callout 
		37) tmna-calloutList 
		38) tmna-calloutOrderList 
		39) tmna-calloutOrderListItem 
		40) tmna-calloutPara 
		41) tmna-calloutParaSub 
		42) tmna-callouts 
		43) tmna-calloutsTitle 
		44) tmna-calloutSymbol 
		45) tmna-calloutTitle 
		46) tmna-diagnosisBody 
		47) tmna-diagnosisCallout 
		48) tmna-diagnosisFigure 
		49) tmna-diagnosisList 
		50) tmna-diagnosisListItem 
		51) tmna-diagnosisPara 
		52) tmna-diagnosisParaSub 
		53) tmna-diagnosisResult 
		54) tmna-diagnosisResultPara 
		55) tmna-diagnosisSection 
		56) tmna-diagnosisSubList 
		57) tmna-diagnosisSubListItem 
		58) tmna-explanation 
		59) tmna-explanationTitle 
		60) tmna-figure 
		61) tmna-footnote 
		62) tmna-indexterm 
		63) tmna-introPara 
		64) tmna-introParaFigure 
		65) tmna-introParaList 
		66) tmna-introParaListItem 
		67) tmna-list 
		68) tmna-listItem 
		69) tmna-listItemPara 
		70) tmna-listItemParaSub 
		71) tmna-note 
		72) tmna-notePara 
		73) tmna-noteParaTitle 
		74) tmna-noteTitle 
		75) tmna-para 
		76) tmna-paraCallout 
		77) tmna-paraSelect 
		78) tmna-paraSelectDiv 
		79) tmna-paraSelectDivTitle 
		80) tmna-paraSub 
		81) tmna-reference 
		82) tmna-refList 
		83) tmna-refPara 
		84) tmna-stepList 
		85) tmna-stepListItem 
		86) tmna-stepPara 
		87) tmna-stepParaSub 
		88) tmna-subList 
		89) tmna-subListItem 
		90) tmna-subSecOverview 
		91) tmna-subSecTopic 
		92) tmna-subSecTopicTitle 
		93) tmna-subSubTopic 
		94) tmna-subSubTopicAdvFunction 
		95) tmna-subSubTopicAdvFunctionTitle 
		96) tmna-subSubTopicBasicFunction 
		97) tmna-subSubTopicBasicFunctionTitle 
		98) tmna-subSubTopicTitle 
		99) tmna-subTopic 
		100) tmna-subTopicAdvFunction 
		101) tmna-subTopicAdvFunctionTitle 
		102) tmna-subTopicBasicFunction 
		103) tmna-subTopicBasicFunctionTitle 
		104) tmna-subTopicBody 
		105) tmna-subTopicBodyTitle 
		106) tmna-subTopicTitle 
		107) tmna-symbol 
		108) tmna-tableFigure 
		109) tmna-tableList 
		110) tmna-tableListItem 
		111) tmna-tableSubList 
		112) tmna-tableSubListItem 
		113) tmna-topicBody 
		114) tmna-uicontrol 
		
Complete list of new classes added to support Semantic Tags

		1) .advanceDescription 
		2) .advanceDescriptionTitle 
		3) .advanceFunction 
		4) .advanceFunctionTitle 
		5) .advanceOperation 
		6) .advanceOperationTitle 
		7) .alert 
		8) .alertTitle 
		9) .alphaIndex 
		10) .alphaIndexList1 
		11) .alphaIndexList2 
		12) .alphaIndexListItem 
		13) .attention 
		14) .attentionCallout 
		15) .attentionFigure 
		16) .attentionList 
		17) .attentionListItem 
		18) .attentionPara 
		19) .attentionParaTitle 
		20) .attentionStep 
		21) .attentionStepItem 
		22) .attentionSubList 
		23) .attentionSubListItem 
		24) .attentionTitle 
		25) .autoControls 
		26) .autoControlsTitle 
		27) .basicDescription 
		28) .basicDescriptionTitle 
		29) .basicFunction 
		30) .basicFunctionTitle 
		31) .basicOperation 
		32) .basicOperationTitle 
		33) .bodyParaGrp 
		34) .bodyParaGrpTitle 
		35) .bodyTitle 
		36) .callout 
		37) .calloutList 
		38) .calloutOrderList 
		39) .calloutOrderListItem 
		40) .calloutPara 
		41) .calloutParaSub 
		42) .callouts 
		43) .calloutsTitle 
		44) .calloutSymbol 
		45) .calloutTitle 
		46) .diagnosisBody 
		47) .diagnosisCallout 
		48) .diagnosisFigure 
		49) .diagnosisList 
		50) .diagnosisListItem 
		51) .diagnosisPara 
		52) .diagnosisParaSub 
		53) .diagnosisResult 
		54) .diagnosisResultPara 
		55) .diagnosisSection 
		56) .diagnosisSubList 
		57) .diagnosisSubListItem 
		58) .explanation 
		59) .explanationTitle 
		60) .figure 
		61) .footnote 
		62) .indexterm 
		63) .introPara 
		64) .introParaFigure 
		65) .introParaList 
		66) .introParaListItem 
		67) .list 
		68) .listItem 
		69) .listItemPara 
		70) .listItemParaSub 
		71) .note 
		72) .notePara 
		73) .noteParaTitle 
		74) .noteTitle 
		75) .para 
		76) .paraCallout 
		77) .paraSelect 
		78) .paraSelectDiv 
		79) .paraSelectDivTitle 
		80) .paraSub 
		81) .reference 
		82) .refList 
		83) .refPara 
		84) .stepList 
		85) .stepListItem 
		86) .stepPara 
		87) .stepParaSub 
		88) .subList 
		89) .subListItem 
		90) .subSecOverview 
		91) .subSecTopic 
		92) .subSecTopicTitle 
		93) .subSubTopic 
		94) .subSubTopicAdvFunction 
		95) .subSubTopicAdvFunctionTitle 
		96) .subSubTopicBasicFunction 
		97) .subSubTopicBasicFunctionTitle 
		98) .subSubTopicTitle 
		99) .subTopic 
		100) .subTopicAdvFunction 
		101) .subTopicAdvFunctionTitle 
		102) .subTopicBasicFunction 
		103) .subTopicBasicFunctionTitle 
		104) .subTopicBody 
		105) .subTopicBodyTitle 
		106) .subTopicTitle 
		107) .symbol 
		108) .tableFigure 
		109) .tableList 
		110) .tableListItem 
		111) .tableSubList 
		112) .tableSubListItem 
		113) .topicBody 
		114) .uicontrol 


*************************************** ****   Updated:9/24/2021   ******************** *************************************

Fix for missing links:
	 • The original links to legacy source files are now pointing to new topic files
	 • Anchor text is now showing Title from corresponding  targets or content modules
	 • Topic title is shown as anchor text if corresponding target is missing title


Improved Graphics:
	 • The size of graphics is increase. Width is still relative to the actual graphic
	 • The height is set to auto
	 • Vertical-align is set to bottom for tmna-symbol
	
Updated tmna-itx.css for tmna-symbol
	
Footnotes:
	 • Superscripts representing footnotes are marked with attribute suptype="footnoteref"
	 • Footnotes are removed from the bottom of the page leave where they appear in the content itself
	 • All the footnotes start *
	 • Footnotes to include class="footnote"
	 • The html mark up for footnote is changed to tmna-footnote
	 
	 
*************************************** ****   Updated:12/09/2021   ******************** *************************************

Implementing new breadcrumb model in HTML pages at the bottom as requested

Updating: tmna-itx.css for breadcrumb support